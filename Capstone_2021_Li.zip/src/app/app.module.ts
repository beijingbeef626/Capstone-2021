import {
    NgModule
} from '@angular/core';
import {
    BrowserModule
} from '@angular/platform-browser';
import {
    FormsModule
} from '@angular/forms';
import {
    HttpClientModule
} from '@angular/common/http';
import {
    IonicModule
} from '@ionic/angular';
import {
    IonicStorageModule
} from '@ionic/storage';
import {
    ApperyioModule
} from './scripts/apperyio/apperyio.module';
import {
    PipesModule
} from './scripts/pipes.module';
import {
    DirectivesModule
} from './scripts/directives.module';
import {
    ComponentsModule
} from './scripts/components.module';
import {
    CustomComponentsModule
} from './scripts/custom-components.module';
import {
    CustomModulesModule
} from './scripts/custom-modules.module';
import {
    app
} from './app';
import {
    AppRoutingModule
} from './app-routing.module';
import {
    ExportedClass as OutgoingDB_Places_list_service
} from './scripts/services/OutgoingDB_Places_list_service';
import {
    ExportedClass as OutgoingDB_Places_create_service
} from './scripts/services/OutgoingDB_Places_create_service';
import {
    ExportedClass as OutgoingDB_Places_update_service
} from './scripts/services/OutgoingDB_Places_update_service';
import {
    ExportedClass as OutgoingDB_Places_query_service
} from './scripts/services/OutgoingDB_Places_query_service';
import {
    ExportedClass as LoginDB_reviews_create_service
} from './scripts/services/LoginDB_reviews_create_service';
import {
    ExportedClass as LoginDB_reviews_read_service
} from './scripts/services/LoginDB_reviews_read_service';
import {
    ExportedClass as LoginDB_reviews_list_service
} from './scripts/services/LoginDB_reviews_list_service';
import {
    ExportedClass as SignupService
} from './scripts/services/SignupService';
import {
    ExportedClass as LogoutService
} from './scripts/services/LogoutService';
import {
    ExportedClass as LoginService
} from './scripts/services/LoginService';
import {
    ExportedClass as FormUtils
} from './scripts/custom/FormUtils';
import {
    WebView
} from '@ionic-native/ionic-webview/ngx';
import {
    Device
} from '@ionic-native/device/ngx';
import {
    SplashScreen
} from '@ionic-native/splash-screen/ngx';
import {
    StatusBar
} from '@ionic-native/status-bar/ngx';
import {
    Keyboard
} from '@ionic-native/keyboard/ngx';
@NgModule({
    declarations: [
        app
    ],
    imports: [
        BrowserModule,
        FormsModule,
        IonicModule.forRoot(),
        HttpClientModule,
        ApperyioModule,
        PipesModule,
        DirectivesModule,
        ComponentsModule,
        CustomComponentsModule,
        CustomModulesModule,
        IonicStorageModule.forRoot(),
        AppRoutingModule
    ],
    bootstrap: [
        app
    ],
    entryComponents: [
        //app
    ],
    providers: [
        StatusBar,
        SplashScreen,
        WebView,
        Device,
        Keyboard,
        OutgoingDB_Places_list_service,
        OutgoingDB_Places_create_service,
        OutgoingDB_Places_update_service,
        OutgoingDB_Places_query_service,
        LoginDB_reviews_create_service,
        LoginDB_reviews_read_service,
        LoginDB_reviews_list_service,
        SignupService,
        LogoutService,
        LoginService,
        FormUtils,
    ]
})
export class AppModule {}