import {
    Component
} from '@angular/core';
import {
    ChangeDetectorRef
} from '@angular/core';
import {
    ApperyioHelperService
} from '../scripts/apperyio/apperyio_helper';
import {
    ApperyioMappingHelperService
} from '../scripts/apperyio/apperyio_mapping_helper';
import {
    $aio_empty_object
} from '../scripts/interfaces';
import {
    ViewChild
} from '@angular/core';
@Component({
    templateUrl: 'Info.html',
    selector: 'page-info',
    styleUrls: ['Info.scss']
})
export class Info {
    public currentItem: any = null;
    public mappingData: any = {};
    public __getMapping(_currentItem, property, defaultValue, isVariable ? , isSelected ? ) {
        return this.$aio_mappingHelper.getMapping(this.mappingData, _currentItem, property, defaultValue, isVariable, isSelected);
    }
    public __setMapping(data: any = {}, keyName: string, propName ? : string): void {
        const changes = data.detail || {};
        if (propName) {
            this.mappingData = this.$aio_mappingHelper.updateData(this.mappingData, [keyName], changes[propName]);
        } else {
            this.mappingData = this.$aio_mappingHelper.updateData(this.mappingData, [keyName], changes.value);
        }
    }
    @ViewChild('j_2', {
        static: false
    }) public j_2;
    constructor(public Apperyio: ApperyioHelperService, private $aio_mappingHelper: ApperyioMappingHelperService, private $aio_changeDetector: ChangeDetectorRef) {}
    ionViewWillEnter() {
        this.pageIonViewWillEnter__j_0();
    }
    ionViewDidEnter() {
        this.pageIonViewDidEnter__j_0();
    }
    async pageIonViewWillEnter__j_0(event ? , currentItem ? ) {
        let __aio_tmp_val__: any;
        /* Invoke data service */
        this.invokeService_listPlaces();
    }
    async pageIonViewDidEnter__j_0(event ? , currentItem ? ) {
        let __aio_tmp_val__: any;
        /* Invoke data service */
        this.invokeService_reviews();
    }
    async search1IonInput__j_2(event ? , currentItem ? ) {
        let __aio_tmp_val__: any;
        /* Invoke data service */
        this.invokeService_searchPlaces();
    }
    async likebuttonClick__j_16(event ? , currentItem ? ) {
        let __aio_tmp_val__: any;
        /* Run TypeScript */
        currentItem.itemData.likes++;
        this.Apperyio.getService("OutgoingDB_Places_update_service").then(
            service => {
                if (!service) {
                    console.log("Error. Service was not found.");
                    return;
                }
                service.execute({
                    data: {
                        likes: currentItem.itemData.likes
                    },
                    params: {
                        _id: currentItem.itemData._id
                    },
                    headers: {}
                }).subscribe(
                    (res: any) => {
                        console.log(res);
                    },
                    (err: any) => {
                        console.log(err)
                    }
                )
            }
        )
    }
    private $aio_dataServices = {
        "listPlaces": "invokeService_listPlaces",
        "searchPlaces": "invokeService_searchPlaces",
        "reviews": "invokeService_reviews"
    }
    invokeService_listPlaces(cb ? : Function) {
        this.Apperyio.getService("OutgoingDB_Places_list_service").then(
            async (service) => {
                if (!service) {
                    console.log("Error. Service was not found.");
                    return;
                }
                let data = {};
                let params = {};
                let headers = {};
                let __aio_tmp_val__: any;
                service.execute({
                    data: data,
                    params: params,
                    headers: headers
                }).subscribe(
                    /* onsuccess */
                    async (res: any) => {
                        if (cb && typeof cb === "function") cb(res);
                    },
                    (err: any) => {
                        console.log(err);
                    }
                )
            }
        );
    }
    invokeService_searchPlaces(cb ? : Function) {
        this.Apperyio.getService("OutgoingDB_Places_query_service").then(
            async (service) => {
                if (!service) {
                    console.log("Error. Service was not found.");
                    return;
                }
                let data = {};
                let params = {};
                let headers = {};
                let __aio_tmp_val__: any;
                this.$aio_changeDetector.detectChanges();
                /* Mapping */
                params = this.$aio_mappingHelper.updateData(params, ['where'], ((value) => {
                    var query = '{"city":"' + value + '"}';
                    console.log("Query value is " + query);
                    return query;
                })(this.$aio_mappingHelper.getComponentPropValue.call(this, 'j_2', 'ionic4search', 'value')));
                service.execute({
                    data: data,
                    params: params,
                    headers: headers
                }).subscribe(
                    /* onsuccess */
                    async (res: any) => {
                        let mappingData: any = {};
                        /* Mapping */
                        (() => {
                            let mappingDataj_3 = typeof mappingData.j_3 === "function" ? mappingData.j_3() : [];
                            mappingData.j_3 = () => {
                                let parentArray = this.$aio_mappingHelper.getSubdata(res, [], []);
                                mappingDataj_3.splice(parentArray.length);
                                parentArray.forEach((v, i) => {
                                    mappingDataj_3[i] = mappingDataj_3[i] || {};
                                    let result__j_3: any = mappingDataj_3[i];
                                    result__j_3.itemData = v;
                                    result__j_3.itemDataParent = parentArray;
                                    result__j_3.j_5__text = this.$aio_mappingHelper.getSubdata(v, ["name"]);
                                    result__j_3.j_9__text = this.$aio_mappingHelper.getSubdata(v, ["likes"]);
                                    result__j_3.j_12__text = this.$aio_mappingHelper.getSubdata(v, ["address"]);
                                    result__j_3.j_13__text = this.$aio_mappingHelper.getSubdata(v, ["city"]);
                                    result__j_3.j_14__text = this.$aio_mappingHelper.getSubdata(v, ["state"]);
                                });
                                return mappingDataj_3;
                            };
                        })();
                        this.mappingData = { ...this.mappingData,
                            ...mappingData
                        };
                        if (cb && typeof cb === "function") cb(res);
                    },
                    (err: any) => {
                        console.log(err);
                    }
                )
            }
        );
    }
    invokeService_reviews(cb ? : Function) {
        this.Apperyio.getService("LoginDB_reviews_list_service").then(
            async (service) => {
                if (!service) {
                    console.log("Error. Service was not found.");
                    return;
                }
                let data = {};
                let params = {};
                let headers = {};
                let __aio_tmp_val__: any;
                this.$aio_changeDetector.detectChanges();
                /* Mapping */
                headers = this.$aio_mappingHelper.updateData(headers, ['X-Appery-Session-Token'], __aio_tmp_val__ = this.$aio_mappingHelper.getServiceDataValue("sessionToken", []));
                service.execute({
                    data: data,
                    params: params,
                    headers: headers
                }).subscribe(
                    /* onsuccess */
                    async (res: any) => {
                        let mappingData: any = {};
                        /* Mapping */
                        (() => {
                            let mappingDataj_17 = typeof mappingData.j_17 === "function" ? mappingData.j_17() : [];
                            mappingData.j_17 = () => {
                                let parentArray = this.$aio_mappingHelper.getSubdata(res, [], []);
                                mappingDataj_17.splice(parentArray.length);
                                parentArray.forEach((v, i) => {
                                    mappingDataj_17[i] = mappingDataj_17[i] || {};
                                    let result__j_17: any = mappingDataj_17[i];
                                    result__j_17.itemData = v;
                                    result__j_17.itemDataParent = parentArray;
                                    result__j_17.j_17__ion4Label_text = this.$aio_mappingHelper.getSubdata(v, ["review"]);
                                });
                                return mappingDataj_17;
                            };
                        })();
                        this.mappingData = { ...this.mappingData,
                            ...mappingData
                        };
                        if (cb && typeof cb === "function") cb(res);
                    },
                    (err: any) => {
                        console.log(err);
                    }
                )
            }
        );
    }
}