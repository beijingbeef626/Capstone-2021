import {
    Component
} from '@angular/core';
import {
    ChangeDetectorRef
} from '@angular/core';
import {
    ApperyioHelperService
} from '../scripts/apperyio/apperyio_helper';
import {
    ApperyioMappingHelperService
} from '../scripts/apperyio/apperyio_mapping_helper';
import {
    $aio_empty_object
} from '../scripts/interfaces';
import {
    ViewChild
} from '@angular/core';
@Component({
    templateUrl: 'Places.html',
    selector: 'page-places',
    styleUrls: ['Places.scss']
})
export class Places {
    public currentItem: any = null;
    public mappingData: any = {};
    public __getMapping(_currentItem, property, defaultValue, isVariable ? , isSelected ? ) {
        return this.$aio_mappingHelper.getMapping(this.mappingData, _currentItem, property, defaultValue, isVariable, isSelected);
    }
    public __setMapping(data: any = {}, keyName: string, propName ? : string): void {
        const changes = data.detail || {};
        if (propName) {
            this.mappingData = this.$aio_mappingHelper.updateData(this.mappingData, [keyName], changes[propName]);
        } else {
            this.mappingData = this.$aio_mappingHelper.updateData(this.mappingData, [keyName], changes.value);
        }
    }
    constructor(public Apperyio: ApperyioHelperService, private $aio_mappingHelper: ApperyioMappingHelperService, private $aio_changeDetector: ChangeDetectorRef) {}
    ionViewDidEnter() {
        this.pageIonViewDidEnter__j_66();
    }
    async pageIonViewDidEnter__j_66(event ? , currentItem ? ) {
        let __aio_tmp_val__: any;
        /* Invoke data service */
        this.invokeService_Places();
    }
    async image1Click__j_81(event ? , currentItem ? ) {
        let __aio_tmp_val__: any;
        /* Run TypeScript */
        currentItem.itemData.likes++;
        this.Apperyio.getService("OutgoingDB_Places_update_service").then(
            service => {
                if (!service) {
                    console.log("Error. Service was not found.");
                    return;
                }
                service.execute({
                    data: {
                        likes: currentItem.itemData.likes
                    },
                    params: {
                        _id: currentItem.itemData._id
                    },
                    headers: {}
                }).subscribe(
                    (res: any) => {
                        console.log(res);
                    },
                    (err: any) => {
                        console.log(err)
                    }
                )
            }
        )
    }
    async logoutbuttonClick__j_85(event ? , currentItem ? ) {
        let __aio_tmp_val__: any;
        /* Invoke data service */
        this.invokeService_LogoutDB();
    }
    private $aio_dataServices = {
        "Places": "invokeService_Places",
        "LogoutDB": "invokeService_LogoutDB"
    }
    invokeService_Places(cb ? : Function) {
        this.Apperyio.getService("OutgoingDB_Places_list_service").then(
            async (service) => {
                if (!service) {
                    console.log("Error. Service was not found.");
                    return;
                }
                let data = {};
                let params = {};
                let headers = {};
                let __aio_tmp_val__: any;
                service.execute({
                    data: data,
                    params: params,
                    headers: headers
                }).subscribe(
                    /* onsuccess */
                    async (res: any) => {
                        let mappingData: any = {};
                        /* Mapping */
                        (() => {
                            let mappingDataj_68 = typeof mappingData.j_68 === "function" ? mappingData.j_68() : [];
                            mappingData.j_68 = () => {
                                let parentArray = this.$aio_mappingHelper.getSubdata(res, [], []);
                                mappingDataj_68.splice(parentArray.length);
                                parentArray.forEach((v, i) => {
                                    mappingDataj_68[i] = mappingDataj_68[i] || {};
                                    let result__j_68: any = mappingDataj_68[i];
                                    result__j_68.itemData = v;
                                    result__j_68.itemDataParent = parentArray;
                                    result__j_68.j_70__text = this.$aio_mappingHelper.getSubdata(v, ["name"]);
                                    result__j_68.j_74__text = this.$aio_mappingHelper.getSubdata(v, ["likes"]);
                                    result__j_68.j_77__text = this.$aio_mappingHelper.getSubdata(v, ["address"]);
                                    result__j_68.j_78__text = this.$aio_mappingHelper.getSubdata(v, ["city"]);
                                    result__j_68.j_79__text = this.$aio_mappingHelper.getSubdata(v, ["state"]);
                                });
                                return mappingDataj_68;
                            };
                        })();
                        this.mappingData = { ...this.mappingData,
                            ...mappingData
                        };
                        if (cb && typeof cb === "function") cb(res);
                    },
                    (err: any) => {
                        console.log(err);
                    }
                )
            }
        );
    }
    invokeService_LogoutDB(cb ? : Function) {
        this.Apperyio.getService("LogoutService").then(
            async (service) => {
                if (!service) {
                    console.log("Error. Service was not found.");
                    return;
                }
                let data = {};
                let params = {};
                let headers = {};
                let __aio_tmp_val__: any;
                this.$aio_changeDetector.detectChanges();
                /* Mapping */
                headers = this.$aio_mappingHelper.updateData(headers, ['X-Appery-Session-Token'], __aio_tmp_val__ = this.$aio_mappingHelper.getServiceDataValue("sessionToken_2", []));
                /* Present Loading */
                await (async () => {
                    let options = {
                        'animated': true,
                        'keyboardClose': true,
                        'showBackdrop': true,
                        'spinner': 'bubbles',
                    }
                    let controller = this.Apperyio.getController('LoadingController');
                    const loading = await controller.create(options);
                    return await loading.present();
                })();
                service.execute({
                    data: data,
                    params: params,
                    headers: headers
                }).subscribe(
                    /* onsuccess */
                    async (res: any) => {
                        let mappingData: any = {};
                        /* Dismiss loading */
                        await this.Apperyio.getController("LoadingController").dismiss();
                        /* Navigate to Page */
                        this.Apperyio.navigateTo('Login');
                        this.mappingData = { ...this.mappingData,
                            ...mappingData
                        };
                        if (cb && typeof cb === "function") cb(res);
                    },
                    /* onerror */
                    async (err: any) => {
                        /* Dismiss loading */
                        await this.Apperyio.getController("LoadingController").dismiss();
                        /* Navigate to Page */
                        this.Apperyio.navigateTo('Login');
                    }
                )
            }
        );
    }
}