import {
    Component
} from '@angular/core';
import {
    ChangeDetectorRef
} from '@angular/core';
import {
    ApperyioHelperService
} from '../scripts/apperyio/apperyio_helper';
import {
    ApperyioMappingHelperService
} from '../scripts/apperyio/apperyio_mapping_helper';
import {
    $aio_empty_object
} from '../scripts/interfaces';
@Component({
    templateUrl: 'CodeConfirmation.html',
    selector: 'page-code-confirmation',
    styleUrls: ['CodeConfirmation.scss']
})
export class CodeConfirmation {
    public code: string;
    public currentItem: any = null;
    public mappingData: any = {};
    constructor(public Apperyio: ApperyioHelperService, private $aio_mappingHelper: ApperyioMappingHelperService, private $aio_changeDetector: ChangeDetectorRef) {}
    async button1Click__j_151(event ? , currentItem ? ) {
        let __aio_tmp_val__: any;
        /* Run TypeScript */
        const localData = await this.Apperyio.data.getStorage("localData");
        await this.Apperyio.data.setStorage("localData", { ...localData,
            code: this.code
        });
    }
}