import {
    NgModule
} from '@angular/core';
import {
    Routes,
    RouterModule
} from '@angular/router';
const routes: Routes = [{
        path: '',
        redirectTo: 'signup',
        pathMatch: 'full'
    },
    {
        path: 'addplace',
        loadChildren: './AddPlace/AddPlace.module#AddPlacePageModule',
    },
    {
        path: 'profile',
        loadChildren: './Places/Places.module#PlacesPageModule',
    },
    {
        path: 'mainpage',
        loadChildren: './NiceTabs/NiceTabs.module#NiceTabsPageModule',
    },
    {
        path: 'info',
        loadChildren: './Info/Info.module#InfoPageModule',
    },
    {
        path: 'login',
        loadChildren: './Login/Login.module#LoginPageModule',
    },
    {
        path: 'signup',
        loadChildren: './SignUp/SignUp.module#SignUpPageModule',
    },
    {
        path: 'home',
        loadChildren: './Home/Home.module#HomePageModule',
    },
    {
        path: 'privacypolicy',
        loadChildren: './PrivacyPolicy/PrivacyPolicy.module#PrivacyPolicyPageModule',
    },
    {
        path: 'termsofservice',
        loadChildren: './TermsOfService/TermsOfService.module#TermsOfServicePageModule',
    },
    {
        path: 'codeconfirmation',
        loadChildren: './CodeConfirmation/CodeConfirmation.module#CodeConfirmationPageModule',
    },
];
@NgModule({
    imports: [RouterModule.forRoot(
        routes, {
            enableTracing: false,
            useHash: true
        }
    )],
    exports: [RouterModule]
})
export class AppRoutingModule {}