import {
    NgModule
} from '@angular/core';
import {
    CommonModule
} from '@angular/common';
import {
    FormsModule
} from '@angular/forms';
import {
    RouterModule
} from '@angular/router';
import {
    Routes
} from '@angular/router';
import {
    IonicModule
} from '@ionic/angular';
import {
    NiceTabs
} from './NiceTabs';
import {
    PipesModule
} from '../scripts/pipes.module';
import {
    DirectivesModule
} from '../scripts/directives.module';
import {
    ComponentsModule
} from '../scripts/components.module';
import {
    CustomComponentsModule
} from '../scripts/custom-components.module';
import {
    CustomModulesModule
} from '../scripts/custom-modules.module';
const routes: Routes = [{
    path: '',
    component: NiceTabs,
    children: [{
            path: 'AddPlace',
            children: [{
                path: '',
                loadChildren: '../AddPlace/AddPlace.module#AddPlacePageModule'
            }]
        },
        {
            path: 'Places',
            children: [{
                path: '',
                loadChildren: '../Places/Places.module#PlacesPageModule'
            }]
        },
        {
            path: 'Info',
            children: [{
                path: '',
                loadChildren: '../Info/Info.module#InfoPageModule'
            }]
        },
        {
            path: '',
            redirectTo: 'Places',
            pathMatch: 'full'
        }
    ]
}];
@NgModule({
    imports: [
        RouterModule.forChild(routes)
    ],
    exports: [RouterModule]
})
export class PageRoutingModule {}
@NgModule({
    declarations: [
        NiceTabs
    ],
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        PipesModule,
        DirectivesModule,
        ComponentsModule,
        CustomComponentsModule,
        CustomModulesModule, PageRoutingModule
    ],
    exports: [
        NiceTabs
    ]
})
export class NiceTabsPageModule {}