import {
    Component
} from '@angular/core';
import {
    ChangeDetectorRef
} from '@angular/core';
import {
    ApperyioHelperService
} from '../scripts/apperyio/apperyio_helper';
import {
    ApperyioMappingHelperService
} from '../scripts/apperyio/apperyio_mapping_helper';
import {
    $aio_empty_object
} from '../scripts/interfaces';
import {
    ViewChild
} from '@angular/core';
@Component({
    templateUrl: 'AddPlace.html',
    selector: 'page-add-place',
    styleUrls: ['AddPlace.scss']
})
export class AddPlace {
    public currentItem: any = null;
    public mappingData: any = {};
    public __getMapping(_currentItem, property, defaultValue, isVariable ? , isSelected ? ) {
        return this.$aio_mappingHelper.getMapping(this.mappingData, _currentItem, property, defaultValue, isVariable, isSelected);
    }
    public __setMapping(data: any = {}, keyName: string, propName ? : string): void {
        const changes = data.detail || {};
        if (propName) {
            this.mappingData = this.$aio_mappingHelper.updateData(this.mappingData, [keyName], changes[propName]);
        } else {
            this.mappingData = this.$aio_mappingHelper.updateData(this.mappingData, [keyName], changes.value);
        }
    }
    @ViewChild('j_55', {
        static: false
    }) public j_55;
    @ViewChild('j_56', {
        static: false
    }) public j_56;
    @ViewChild('j_57', {
        static: false
    }) public j_57;
    @ViewChild('j_58', {
        static: false
    }) public j_58;
    @ViewChild('j_59', {
        static: false
    }) public j_59;
    constructor(public Apperyio: ApperyioHelperService, private $aio_mappingHelper: ApperyioMappingHelperService, private $aio_changeDetector: ChangeDetectorRef) {}
    async button1Click__j_60(event ? , currentItem ? ) {
        let __aio_tmp_val__: any;
        /* Invoke data service */
        this.invokeService_addPlace();
    }
    private $aio_dataServices = {
        "addPlace": "invokeService_addPlace"
    }
    invokeService_addPlace(cb ? : Function) {
        this.Apperyio.getService("OutgoingDB_Places_create_service").then(
            async (service) => {
                if (!service) {
                    console.log("Error. Service was not found.");
                    return;
                }
                let data = {};
                let params = {};
                let headers = {};
                let __aio_tmp_val__: any;
                this.$aio_changeDetector.detectChanges();
                data = this.$aio_mappingHelper.updateData(data, ["likes"], '0');
                /* Mapping */
                data = this.$aio_mappingHelper.updateData(data, ["name"], this.$aio_mappingHelper.getComponentPropValue.call(this, 'j_55', 'ionic4input', 'value'));
                data = this.$aio_mappingHelper.updateData(data, ["address"], this.$aio_mappingHelper.getComponentPropValue.call(this, 'j_56', 'ionic4input', 'value'));
                data = this.$aio_mappingHelper.updateData(data, ["city"], this.$aio_mappingHelper.getComponentPropValue.call(this, 'j_57', 'ionic4input', 'value'));
                data = this.$aio_mappingHelper.updateData(data, ["state"], this.$aio_mappingHelper.getComponentPropValue.call(this, 'j_58', 'ionic4input', 'value'));
                data = this.$aio_mappingHelper.updateData(data, ["zipcode"], this.$aio_mappingHelper.getComponentPropValue.call(this, 'j_59', 'ionic4input', 'value'));
                /* Present Loading */
                await (async () => {
                    let options = {
                        'animated': true,
                        'keyboardClose': true,
                        'message': 'Uploading',
                        'showBackdrop': true,
                        'spinner': 'circular',
                    }
                    let controller = this.Apperyio.getController('LoadingController');
                    const loading = await controller.create(options);
                    return await loading.present();
                })();
                service.execute({
                    data: data,
                    params: params,
                    headers: headers
                }).subscribe(
                    /* onsuccess */
                    async (res: any) => {
                        let mappingData: any = {};
                        /* Dismiss loading */
                        await this.Apperyio.getController("LoadingController").dismiss();
                        /* Navigate to Page */
                        this.Apperyio.navigateTo('NiceTabs');
                        this.mappingData = { ...this.mappingData,
                            ...mappingData
                        };
                        if (cb && typeof cb === "function") cb(res);
                    },
                    (err: any) => {
                        console.log(err);
                    }
                )
            }
        );
    }
}