import {
    ExportedClass as OutgoingDB_Places_list_service
} from './services/OutgoingDB_Places_list_service';
import {
    ExportedClass as OutgoingDB_Places_create_service
} from './services/OutgoingDB_Places_create_service';
import {
    ExportedClass as OutgoingDB_Places_update_service
} from './services/OutgoingDB_Places_update_service';
import {
    ExportedClass as OutgoingDB_Places_query_service
} from './services/OutgoingDB_Places_query_service';
import {
    ExportedClass as LoginDB_reviews_create_service
} from './services/LoginDB_reviews_create_service';
import {
    ExportedClass as LoginDB_reviews_read_service
} from './services/LoginDB_reviews_read_service';
import {
    ExportedClass as LoginDB_reviews_list_service
} from './services/LoginDB_reviews_list_service';
import {
    ExportedClass as SignupService
} from './services/SignupService';
import {
    ExportedClass as LogoutService
} from './services/LogoutService';
import {
    ExportedClass as LoginService
} from './services/LoginService';
import {
    ExportedClass as FormUtils
} from './custom/FormUtils';
export const services = {
    OutgoingDB_Places_list_service,
    OutgoingDB_Places_create_service,
    OutgoingDB_Places_update_service,
    OutgoingDB_Places_query_service,
    LoginDB_reviews_create_service,
    LoginDB_reviews_read_service,
    LoginDB_reviews_list_service,
    SignupService,
    LogoutService,
    LoginService,
    FormUtils,
};