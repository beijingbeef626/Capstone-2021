export const constants = {
    /**
     * SecuritySettings
     * @property database_id       - 
     */
    SecuritySettings: {
        "database_id": "603ee8812e22d72d8370094c"
    },
    /**
     * Settings
     */
    Settings: {},
    /**
     * OutgoingDB_settings
     * @property database_id       - 
     */
    OutgoingDB_settings: {
        "database_id": "60242ab62e22d747ad207ca3"
    },
    /**
     * LoginDB_settings
     * @property database_id       - 
     */
    LoginDB_settings: {
        "database_id": "603ee8812e22d72d8370094c"
    }
};
export const routes = {
    "AddPlace": "addplace",
    "Places": "profile",
    "NiceTabs": "mainpage",
    "search": "info",
    "Login": "login",
    "SignUp": "signup",
    "Home": "home",
    "PrivacyPolicy": "privacypolicy",
    "TermsOfService": "termsofservice",
    "CodeConfirmation": "codeconfirmation",
    "SignUp_clone_1": "signup_clone_1",
};
export const pushSettings = {
    appID: 'bfa29792-742c-4c1b-8e51-306f2fc52112',
    baseUrl: 'https://api.appery.io/rest/push/reg',
    initOptions: {}
};