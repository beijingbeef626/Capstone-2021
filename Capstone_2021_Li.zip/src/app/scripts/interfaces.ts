// Appery.io models
export interface $aio_empty_object {};
//
export interface LoginDB_reviews_create_serviceResponse {
    "_createdAt": string,
    "_id": string
}
//
interface __LoginDB_reviews_read_serviceResponse_sub_002 {
    "write": boolean,
    "read": boolean
}
interface __LoginDB_reviews_read_serviceResponse_sub_001 {
    "*": __LoginDB_reviews_read_serviceResponse_sub_002
}
export interface LoginDB_reviews_read_serviceResponse {
    "_createdAt": string,
    "acl": __LoginDB_reviews_read_serviceResponse_sub_001,
    "_id": string,
    "review": string,
    "_updatedAt": string
}
//
interface __LoginDB_reviews_list_serviceResponse_sub_003 {
    "read": boolean,
    "write": boolean
}
interface __LoginDB_reviews_list_serviceResponse_sub_002 {
    "*": __LoginDB_reviews_list_serviceResponse_sub_003
}
interface __LoginDB_reviews_list_serviceResponse_sub_001 {
    "review": string,
    "acl": __LoginDB_reviews_list_serviceResponse_sub_002,
    "_createdAt": string,
    "_id": string,
    "_updatedAt": string
}
export interface LoginDB_reviews_list_serviceResponse extends Array < __LoginDB_reviews_list_serviceResponse_sub_001 > {}
//
interface __OutgoingDB_Places_list_serviceResponse_sub_003 {
    "read": boolean,
    "write": boolean
}
interface __OutgoingDB_Places_list_serviceResponse_sub_002 {
    "*": __OutgoingDB_Places_list_serviceResponse_sub_003
}
interface __OutgoingDB_Places_list_serviceResponse_sub_001 {
    "likes": string,
    "city": string,
    "zipcode": number,
    "state": string,
    "address": string,
    "_id": string,
    "_updatedAt": string,
    "acl": __OutgoingDB_Places_list_serviceResponse_sub_002,
    "_createdAt": string,
    "name": string
}
export interface OutgoingDB_Places_list_serviceResponse extends Array < __OutgoingDB_Places_list_serviceResponse_sub_001 > {}
//
interface __OutgoingDB_Places_query_serviceResponse_sub_003 {
    "write": boolean,
    "read": boolean
}
interface __OutgoingDB_Places_query_serviceResponse_sub_002 {
    "*": __OutgoingDB_Places_query_serviceResponse_sub_003
}
interface __OutgoingDB_Places_query_serviceResponse_sub_001 {
    "state": string,
    "name": string,
    "likes": string,
    "zipcode": number,
    "_updatedAt": string,
    "address": string,
    "city": string,
    "_id": string,
    "acl": __OutgoingDB_Places_query_serviceResponse_sub_002,
    "_createdAt": string
}
export interface OutgoingDB_Places_query_serviceResponse extends Array < __OutgoingDB_Places_query_serviceResponse_sub_001 > {}
//
export interface LoginServiceResponse {
    "_id": string,
    "sessionToken": string
}
//
export interface OutgoingDB_Places_create_serviceResponse {
    "_createdAt": string,
    "_id": string
}
//
export interface LogoutServiceResponse {}
//
export interface OutgoingDB_Places_update_serviceResponse {
    "_updatedAt": string
}
//
export interface SignupServiceResponse {
    "_updatedAt": string,
    "username": string,
    "_id": string,
    "_createdAt": string,
    "sessionToken": string
}